/*-------------------------------------------------------------------------
 *
 * tarrable.h
 *
 *
 * Copyright (c) 2019-Present VMware, Inc. or its affiliates.
 *
 *
 * IDENTIFICATION
 *	    src/include/utils/tarrable.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef TARRABLE_H
#define TARRABLE_H

#define MAX_TARABLE_SYMLINK_PATH_LENGTH 100

#endif /* TARRABLE_H */

